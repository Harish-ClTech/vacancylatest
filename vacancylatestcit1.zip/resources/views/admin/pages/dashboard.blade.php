
<div id="kt_content_container" class="container-xxl">
    <!--begin::Card-->
    <div class="card">
        <!--begin::Card header-->
        <div class="card-header border-0 pt-6">
            <!--begin::Card toolbar-->
            <div class="card-toolbar">
                <div class="d-flex justify-content-end">
                    Dashboard
                </div>
                <!--end::Toolbar-->
            </div>
            <!--end::Card toolbar-->
        </div>
        <!--end::Card header-->
        <!--begin::Card body-->
        <div class="card-body py-4">
            <!--begin::Table-->
            <div id="kt_table_users_wrapper" class="dataTables_wrapper dt-bootstrap4 no-footer">
                <div class="table-responsive">
                    <table class="table-bordered table-striped table-condensed cf" id="experienceDetailTable"
                        width="100%">
                        <thead class="cf">
                            <tr>
                                <th>क्रम संख्या </th>
                                <th>विज्ञापन नं</th>
                                <th>Form Verification</th>
                                <th>Admit Card</th>

                            </tr>

                        </thead>

                        <tbody>

                            <tr>

                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <!--end::Table-->
        </div>
        <!--end::Card body-->
    </div>
    <!--end::Card-->
</div>


