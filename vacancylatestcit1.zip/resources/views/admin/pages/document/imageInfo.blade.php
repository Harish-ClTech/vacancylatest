<div class="row">
      <img src="{{@$image_path}}" alt="Sample Image">
      <p class="info">{!! $description !!}</p>
</div>